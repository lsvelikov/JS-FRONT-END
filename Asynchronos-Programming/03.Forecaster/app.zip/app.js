function attachEvents() {

    const baseUrl = 'http://localhost:3030/jsonstore/forecaster';

    const getWeatherBtn = document.querySelector('#submit');
    const locationInputElement = document.querySelector('#location');
    const forecastElement = document.querySelector('#forecast');
    const currentElement = document.querySelector('#current');
    const upcomingElement = document.querySelector('#upcoming');


    let conditions = {
        'Sunny': '☀',
        'Partly sunny': '⛅',
        'Overcast': '☁',
        'Rain': '☂',
        'Degrees': '°',
    }

    getWeatherBtn.addEventListener('click', (e) => {

        fetch(`${baseUrl}/locations`)
            .then(response => response.json())
            .then(data => {

                const { code } = data.find(data => data.name === locationInputElement.value);

                return Promise.all([
                    fetch(`${baseUrl}/today/${code}`),
                    fetch(`${baseUrl}/upcoming/${code}`),
                ]);
            })
            .then(responses => Promise.all(responses.map(response => response.json())))
            .then(([today, upcoming]) => {

                forecastElement.style.display = 'block';

                const symbolSpanElement = document.createElement('span');
                symbolSpanElement.classList.add('condition');
                symbolSpanElement.classList.add('symbol');
                symbolSpanElement.textContent = conditions[today.forecast.condition];

                const anotherSpan = document.createElement('span');
                anotherSpan.classList.add('condition');

                const spanCityName = document.createElement('span');
                spanCityName.classList.add('forecast-data');
                spanCityName.textContent = `${today.name}`;

                const spanTempElement = document.createElement('span');
                spanTempElement.classList.add('forecast-data');
                spanTempElement.textContent = `${today.forecast.low}°/${today.forecast.high}°`;

                const spanConditionElement = document.createElement('span');
                spanConditionElement.classList.add('forecast-data');
                spanConditionElement.textContent = `${today.forecast.condition}`;

                anotherSpan.appendChild(spanCityName);
                anotherSpan.appendChild(spanTempElement);
                anotherSpan.appendChild(spanConditionElement);

                const forecastsElement = document.createElement('div');
                forecastsElement.classList.add('forecasts');
                forecastsElement.appendChild(symbolSpanElement);
                forecastsElement.appendChild(anotherSpan);

                currentElement.appendChild(forecastsElement);

                const upcomingDiv = document.createElement('div');
                upcomingDiv.classList.add('forecast-info');

                for (let day of upcoming.forecast) {
                    const upcomingSpan = document.createElement('span');
                    upcomingSpan.classList.add('upcoming');

                    const spanSymbol = document.createElement('span');
                    spanSymbol.classList.add('symbol');
                    spanSymbol.textContent = [conditions[day.condition]];

                    const spanTemperature = document.createElement('span');
                    spanTemperature.classList.add('forecast-data');
                    spanTemperature.textContent = `${day.low}°/${day.high}°`;

                    const spanCondition = document.createElement('span');
                    spanCondition.classList.add('forecast-data');
                    spanCondition.textContent = `${day.condition}`;

                    upcomingSpan.appendChild(spanSymbol);
                    upcomingSpan.appendChild(spanTemperature);
                    upcomingSpan.appendChild(spanCondition);

                    upcomingDiv.appendChild(upcomingSpan);

                }

                upcomingElement.appendChild(upcomingDiv);

            })
            .catch((error) => console.log('Error'));

    });
}

attachEvents();